<?php

include "connection.php";
include "functions.php";

 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form  action="" method="post" enctype="multipart/form-data">
  
      <button type="submit" name="account">Account</button>
    </form>

    <form  action="" method="post">
      <button type="submit" name="subjects">subjects</button>
    </form>
  </body>
</html>
<?php

extract($_POST);
if (isset($subjects)) {
    echo '

    <form  action="" method="post">

    <button type="submit" name="add_sub">add subject</button>

    </form>

    <form  action="" method="post">

    <button type="submit" name="update_subject">update subject</button>
    <input type="number" name="subject_id" value="">

    </form>
    ';
}
if (isset($account)) {
    echo '

    <form class="" action="" method="post">


    <button type="submit" name="add">add</button>

    </form>

    <form  action="" method="post">

       <button type="submit" name="update">update</button>

       <input type="number" name="id" value="">

    </form>';
}
if (isset($add)) 
{
  echo '  <form  action="admin.php" method="post" enctype="multipart/form-data">
                Account ID : <input type="number" name="id" value=""><br>

                Password : <input type="password" name="password" value=""><br>

                Priv : <select class="" name="priv">
                        <option value="" selected="selected">chose your priv</option>
                        <option value="s">student</option>
                        <option value="t">tetcher</option>
                      </select><br>

                Name : <input type="text" name="name" value=""><br>
                phone : <input type="number" name="phone" value=""><br>
                email : <input type="email" name="email" value=""><br>
                state : <select class="" name="status">
                            <option value="" selected="selected">your status</option>
                            <option value="e">enable</option>
                            <option value="d">desable</option>
                         </select><br>
                

               <input type="submit" name="add_account" value="add">

             </form>';
}

if (isset($update)) {

  if (select_id($id,$result,$conn)) {

       echo '<form  action="" method="post">';
           if ($result[0]['priv']=='s') {
                echo '
                Priv : <select class="" name="priv">
                <option value="s" selected>student</option>
                <option value="t">tetcher</option>

                </select><br>';
      }else{
            echo '
            Priv : <select class="" name="priv">
            <option value="s">student</option>

            <option value="t" selected>tetcher</option>


            </select><br>';
          }


      echo'
      <input type="number" name="id" value="'.$result[0]['id'].'" disable><br>
      Name : <input type="text" name="name" value="'.$result[0]['name'].'"><br>
      phone : <input type="number" name="phone" value="'.$result[0]['phone'].'"><br>
      email : <input type="email" name="email" value="'.$result[0]['email'].'"><br>
      ';


  if ($result[0]['status']=='d') {
      echo '
      state : <select class="" name="status">
      <option value="e">enable</option>
      <option value="d"selected>desable</option>
      </select><br>
      ';
  }else{
      echo '
      state : <select class="" name="status">
      <option value="e"selected>enable</option>
      <option value="d">desable</option>
      </select><br>';
  }
      echo '
      <button type="submit" name="edit">update</button>
      </form>';

}else {
echo "id nnnn";
}

}

if(isset($update_subject)){
  if(select_subject($subject_id,$result,$conn))
  {
    echo '


      <form  action="" method="post">
    Subject ID  <input type="number" name="id" value="'.$result[0]['id'].'"><br>
    Subject name  <input type="text" name="name" value="'.$result[0]['name'].'"><br>
    <input type="submit" name="edit_subject" value="update">
    </form> ';
  }
}

if(isset($edit_subject)){
  if(  update_subject($id,$name,$result,$conn))
  {
    echo "successful";
  }
  else
  {
  echo $result ;
  }
}

if(isset($add_sub)){
  echo '


    <form  action="" method="post">
       Subject ID  <input type="number" name="id"><br>
       Subject name  <input type="text" name="name" value=""><br>
       <input type="submit" name="add_subject" value="add">
   </form> ';



}

if (isset($add_subject)) {

  if(add_subject($id,$name,$result,$conn))
  {
  echo "true";
  }else {
  echo $result;
  }


}

if (isset($add_account)) {

     
    
if(add_account($id,$password,$priv,$name,$phone,$email,$status,$result,$dst1,$conn))
{
  
echo "true";
}else {
echo $result;
}
  // code...
}

if(isset($edit))
{
if(update_account($id,$priv,$name,$phone,$email,$status,$result,$conn))
echo "update successful";

else
  echo $result;
}

 ?>
