<?php 
session_start();
include "connection.php";
include "functions.php";
extract($_GET);
// session_unset();
// session_destroy();
if (isset($logout)) {
  session_unset();
  session_destroy();
}
 

 


?>
<!DOCTYPE html>


<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>index</title>
  </head>
  <body>
    <form  action="" method="post">
ID : <input type="number" name="id" value="">
Password :      <input type="password" name="password" value="">
      <input type="submit" name="login" value="login">
    </form>
  </body>
</html>

<?php


extract($_POST);

if (isset($login))
{
if (Login_check($id,$password,$result,$conn))
{
$priv = $result[0]['priv'];
session_start();
$_SESSION['id'] = $result[0]['id'];


switch ($priv) {
  case 's':
  header('Location: student.php');
break;
    case 't':
    header('Location: courses.php');
    break;

  default:
    // code...
    break;
}
}
else
echo $result;
}




 ?>
