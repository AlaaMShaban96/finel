<?php

function Login_check($id,$password,&$result,$conn)
{session_start();

  $stm = "SELECT * FROM `accounts` WHERE id=$id";
  try {

          $result = $conn->query($stm);
          $result = $result->fetchall();

     if ($result==null){

        $result = "id not found";

        return false;
     }
    else {
          if ($result[0]['password']==$password){
                
                $_SESSION['s_id']    =$result[0]['id'];
                $_SESSION['priv']    =$result[0]['priv'];
                $_SESSION['name']    =$result[0]['name'];
                $_SESSION['phone']   =$result[0]['phone'];
                $_SESSION['email']   =$result[0]['email'];
                $_SESSION['status']  =$result[0]['status'];
                $_SESSION['password']=$result[0]['password'];
                $_SESSION['img']     =$result[0]['img'];
              
                return true;
          } 
          else{

                $result = "password not correct";
                return false;
          }
        }
     } catch (\Exception $e){
            $result = "all feilds required :)";
           }

}

function add_account($id,$password,$priv,$name,$phone,$email,$status,&$result,$dis,$conn)
{
 
  $stm="INSERT INTO `accounts`(`password`, `priv`, `name`, `phone`, `email`, `status`,`img`) VALUES ('$password','$priv','$name',$phone,'$email','$status','$dis')";
  $conn->exec($stm);
  
  $result="true";
  return true;
}


function add_subject($id,$name,&$result,$conn)
{
  $stm="INSERT INTO `subjects`(`id`, `name`) VALUES ($id,'$name')";


    $conn->exec($stm);
    $result="true";
}


function update_account($id,$priv,$name,$phone,$email,$status,&$result,$conn)
{
  try {
  $stm= "UPDATE `accounts` SET `priv`='$priv',`name`='$name',`phone`=$phone,`email`='$email',`status`='$status' WHERE id=$id";

  $conn->exec($stm);
  return true;

  }catch (\Exception $e) {
    $result="database error ";
  return false;
    }
}

function select_id($id,&$result,$conn)
{
  $stm = "SELECT * FROM `accounts` WHERE id=$id";
  try {

    $result = $conn->query($stm);
    $result = $result->fetchall();

    if ($result==null) {
         $result = "id not found";
        return false;
       }else {
        return true;
        }

    } catch (\Exception $e){
         $result = " you entered failed value :)";
       }
}

function select_subject($subject_id,&$result,$conn)
{
    $stm = "SELECT * FROM `subjects` WHERE id=$subject_id";
  try {

      $result = $conn->query($stm);
      $result = $result->fetchall();

      if ($result==null)
      {
  $result = "id not found";
  return false;

  }else {
    return true;
  }

  } catch (\Exception $e){
  $result = " you entered failed value :)";
  }
}

function update_subject($id,$name,&$result,$conn)
{
    try {
    $stm= "UPDATE `subjects` SET `name`='$name' WHERE id=$id";

    $conn->exec($stm);
  return true;

  } catch (\Exception $e) {
  $result="database error ";
    return false;
  }
}
/** this finction for add and drop courses on students*/
function number_of_courses($conn)
{
  $stm = "SELECT COUNT(`id`) as`id_num`FROM `courses` WHERE  `courses`.`status`='o' ";
  try {
    

    $result = $conn->query($stm);
    $result = $result->fetchall();

    if ($result==null) {
         $result = "id not found";
        return false;
       }else {
        return $result[0]['id_num'];
        }

    } catch (\Exception $e){
      return $result = " you entered failed value :)";
       }
  
}
function number_of_your_courses($conn,$id)
{
  $stm = "SELECT COUNT(`id`) as`id_num`FROM `registration` WHERE s_id=$id and `registration`.`status`='r' ";
  try {
    

    $result = $conn->query($stm);
    $result = $result->fetchall();

    if ($result==null) {
         $result = "id not found";
        return false;
       }else {
        return $result[0]['id_num'];
        }

    } catch (\Exception $e){
      return $result = " you entered failed value :)";
       }
  
}
function all_courses($conn)
{
  
  $stm  = "SELECT `courses`.id,`subjects`.`name` from `courses` JOIN `subjects` on
               `courses`.`su_id` = `subjects`.`id`  and `courses`.`status`='o'";
   try {
    

    $result = $conn->query($stm);
    $result = $result->fetchall();
   

    if ($result==null) {
         
        return $result;
       }else {

        return $result;
        }

    } catch (\Exception $e){
      return $result[0] = " you entered failed value :)";
       }
}
function my_courses($conn,$id)
{
  
  $stm  = "SELECT `courses`.id,`subjects`.`name`,`courses`.`t_id` from `courses` JOIN `subjects` on
   `courses`.`su_id` = `subjects`.`id` JOIN `registration` ON
   `courses`.`id` =`registration`.`c_id` WHERE  `registration`.`s_id`= $id and `registration`.`status`='r'";
   try {
    

    $result = $conn->query($stm);
    $result = $result->fetchall();
   

    if ($result==null) {
         
        return $result;
       }else {

        return $result;
        }

    } catch (\Exception $e){
      return $result = " you entered failed value :)";
       }
}
function drop_courses($conn,$s_id,$c_id)
{
  var_dump($c_id);
  var_dump($s_id);
  try {
    $stm= "UPDATE `registration` SET `status`='d' WHERE `registration`.`c_id`=$c_id and `registration`.`s_id`=$s_id";

    $conn->exec($stm);
  return true;

  } catch (\Exception $e) {
  var_dump($e);
    return false;
  }
}
function add_courses($conn,$s_id,$c_id)
{
  
  try {
    $stm= "INSERT INTO `registration`( `s_id`, `c_id`, `status`) VALUES ($s_id,$c_id,'r')";
    $conn->exec($stm);
  return true;

  } catch (\Exception $e) {
  var_dump($e);
    return false;
  }
}


/* this function for open and close courses teatcher   */ 

function add_course($t_id,$subject_id,$conn)
{

  $stm="INSERT INTO `courses`(`t_id`, `su_id`, `status`) VALUES ($t_id,$subject_id,'o')";
   try {
    $conn->exec($stm);
    return true;
   } catch (\Throwable $th) {
    return false;
   }
   
    
}



function select_subject_id(&$result,$conn)
{
  $stm = "SELECT * FROM `subjects`";

    $result = $conn->query($stm);
    $result = $result->fetchall();
    return true;
}



function select_courses_status($t_id,&$result,$conn)
{

  $stm = "SELECT `courses`.id,`subjects`.`name` from `courses` JOIN `subjects` on 
  `courses`.`su_id` = `subjects`.`id` and `courses`.`status`='o' and `courses`.`t_id`=$t_id  ";

    $result = $conn->query($stm);
    $result = $result->fetchall();
    return true;
}


function close_course($subject_id,&$result,$conn)
{
    try {
    $stm= "UPDATE `courses` SET `status`='c' WHERE id=$subject_id";

    $conn->exec($stm);
  return true;

  } catch (\Exception $e) {
  $result="database error ";
    return false;
  }
}

// for getting corsues id function
function get_coruses($teacher_id , &$result , $conn)
{
  try {
    $stm = "SELECT `id` FROM `courses` WHERE t_id = '$teacher_id'";
    $result = $conn->query($stm);
    $result = $result->fetchall();
    if($result == null){

      $result = "Courses Not Found" ;
      return false;
    }else {
      return true;
    }
  } catch (\Exception $e) {
    $result = "please Enter Valid Values";
  }

}

function get_Sts_in_cr($subject_id,&$result,$conn)
{
  try {
    $stm = "SELECT `s_id` FROM `registration` WHERE c_id = '$subject_id' and status = 'r'";
    $result = $conn->query($stm);
    $result = $result->fetchall();
    if($result == null){
      
      return false;
    }else {
      return true;
    }
  } catch (\Exception $e) {
    $result = "please Enter Valid Values";
  }
}
function insert_deg($st_id,$c_id,$t_id,$mid,$final,&$result2,$conn)
{
  try {
    $stm="INSERT INTO `results` (`s_id`, `c_id`, `t_id`, `mid`, `final`) VALUES ('$st_id', '$c_id', '$t_id', '$mid', '$final')";
      $conn->exec($stm);
      $result2="Your Request Copmplete";
      return true ;
  } catch (\Exception $e) {
    $result2 = "Please Fill All fields";
    return false;
  }

}


function get_gred($t_id,$c_id,&$result_for_gred,$conn)
{
  
  try {
    $stm = "SELECT `mid`, `final` FROM `results` WHERE `c_id` = '$c_id'  AND `t_id` =$t_id";
    $result_for_gred = $conn->query($stm);
    $result_for_gred = $result_for_gred->fetchall();
    if ($result_for_gred == null) {
      return false;
    }else {
      return true;
    }
   
  } catch (\Exception $e) {
    echo "string";
  }
  
}


function update_grade($st_id,$c_id,$t_id,$mid,$final,&$result2,$conn)
{
  try {
    $stm= "  UPDATE `results` SET
    `mid`=$mid,`final`=$final WHERE `s_id`= $st_id AND `c_id`= $c_id and `t_id`=$t_id ";
    $conn->exec($stm);
    $result2 ="Done";
  } catch (\Exception $e) {
 echo "string";
  }

}

function show_results($s_id,&$result,$conn)
{
  $stm = "SELECT c_id,mid,final FROM `results` where s_id=$s_id";

    $result = $conn->query($stm);
    $result = $result->fetchall();
    return true;
}
