-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 07, 2019 at 11:45 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(5) NOT NULL,
  `priv` varchar(1) NOT NULL COMMENT 'privilege t = teacher / s = student  ',
  `name` varchar(50) NOT NULL,
  `phone` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT 'e' COMMENT 'e = enabled (default) / d = disabled',
  `password` int(11) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `priv`, `name`, `phone`, `email`, `status`, `password`, `img`) VALUES
(4, '', 'alaa', 123456789, '', 'e', 123456789, 'img/fad5d9b246471d48cd5b9d4be5dfbc563_399.jpg'),
(12, 's', 'Alaa Mohammed', 927780208, 'aa@aa.com', 'e', 123, ''),
(13, 's', 'ahmed', 927777777, 'ahmed@ah.com', 'e', 111, 'img/a2f1f7bceede47f01419d0218a8afde4'),
(14, 's', 'kaled', 9255555, 'kh@ka.com', 'e', 111, 'img/f127aa5bbe3fb685d1761ca8e8bb5dae'),
(15, 's', 'dubel zero', 218927780, 'oo@oo.com', 'e', 0, 'img/a42da4fb846d90cf9d618a7090a727c2'),
(16, 't', 'osame', 888888888, 'os@os.com', 'e', 88, 'img/e42d42e74ec350692b7ee109905c1603670395_question-mark-png.png'),
(17, 's', 'pppp', 7777, 'pp@pp.com', 'e', 77, 'img/b1a01f990419c8321792d9b23429c1a2software-testing.png'),
(18, 's', 'aaaa', 1234, 'alaa@alaa.com', 'e', 44, 'img/65bdb10328219cb0763d7e6659a35768curriculum-clipart-student-outcome-5.png'),
(19, 's', 'dddd444', 0, 'dd@dd.com', 'e', 0, 'img/f8438664cd006998b70d7d497eb22684670395_question-mark-png.png'),
(20, 's', 'lll', 8989, 'll@ll.com', 'e', 8989, 'img/360-3600811_control-icon-blk-settings-search-icon.png'),
(21, 's', 'mmm', 8888, 'moh@mo.com', 'e', 0, 'img/670395_question-mark-png.png'),
(22, 's', 'hhhh', 787656, 'alaa@alaa.com', 'e', 0, 'img/670395_question-mark-png.png'),
(23, 's', 'hhhh', 787656, 'alaa@alaa.com', 'e', 0, 'img /670395_question-mark-png.png'),
(24, 's', 'hhhh', 787656, 'alaa@alaa.com', 'e', 0, 'img/670395_question-mark-png.png');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(5) NOT NULL,
  `t_id` int(5) NOT NULL COMMENT 'teacher id',
  `su_id` int(5) NOT NULL COMMENT 'subject id',
  `status` varchar(1) NOT NULL DEFAULT 'o' COMMENT 'o = opened (default)/ c = closed'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `t_id`, `su_id`, `status`) VALUES
(1, 0, 0, 'o'),
(2, 1, 1, 'o'),
(3, 1, 2, 'o'),
(8, 1, 4, 'o'),
(4, 16, 2, 'c'),
(9, 16, 0, 'c'),
(10, 16, 4, 'c'),
(11, 16, 1, 'c'),
(12, 16, 2, 'c'),
(13, 16, 1, 'c'),
(14, 16, 1, 'c'),
(15, 16, 2, 'c'),
(16, 16, 1, 'c'),
(17, 16, 1, 'o'),
(18, 16, 2, 'o');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(5) NOT NULL,
  `s_id` int(5) NOT NULL COMMENT 'student id',
  `c_id` int(5) NOT NULL COMMENT 'course id',
  `status` varchar(1) NOT NULL DEFAULT 'r' COMMENT 'r = registered (default) / d = dropped'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `s_id`, `c_id`, `status`) VALUES
(21, 17, 18, 'r'),
(20, 17, 18, 'r'),
(19, 17, 18, 'r'),
(18, 17, 18, 'r'),
(16, 17, 8, 'd'),
(17, 17, 8, 'd');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int(5) NOT NULL,
  `s_id` int(5) NOT NULL COMMENT 'student id',
  `c_id` int(5) NOT NULL COMMENT 'course id',
  `t_id` int(5) NOT NULL COMMENT 'teacher id',
  `mid` float NOT NULL,
  `final` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `s_id`, `c_id`, `t_id`, `mid`, `final`) VALUES
(7, 17, 18, 16, 0, 0),
(1, 17, 1, 16, 29, 80);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`) VALUES
(1, 'c++'),
(2, 'html'),
(0, 'java'),
(4, 'php');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
