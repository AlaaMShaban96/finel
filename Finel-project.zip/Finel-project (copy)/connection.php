<?php
$dsn="mysql:host=localhost;dbname=project";
$dbuser="root";
$dbpass="";
try{
 $conn= new PDO($dsn,$dbuser,$dbpass/*,$option*/);  // create an object from built-in PDO class
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 // echo "connection done";
}
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    // var_dump($e);
    }
 ?>
