<?php

include "connection.php";
include "functions.php";

 ?>
<style>
.button {
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color: #3e8e41}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

</style>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="bootstrap/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title></title>
  </head>
  <body>
    <form  action="" method="post">

    <button class="button" type="submit"  name="add_course">Show All subjects</button>

    </form>

    <form  action="" method="post">

    <button class="button" type="submit" name="close_course">my course</button>

    </form>
<!-- 
    <form  action="Results.php" method="post">

    <button class="button" type="submit" >Results</button>

    </form> -->
    <form action="index.php" method="get" >
         <input type="submit" class="btn btn-warning" value="Log out " name="logout">
     </form>  

  </body>
</html>
<?php
session_start();
extract($_POST);
if(isset($add_course))
{


    if(select_subject_id($result,$conn)){
      ?>
      <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">subject name</th>
      
      </tr>
    </thead>
      <?php
    foreach ($result as $key => $value) {
      ?>
    <tr>
    

    <td><?= $result[$key]['name']?></td>

    <td>
          <form action="" method="post">
              <input type="text" name="subject_id" value="<?= $result[$key]['id']?>" style="display: none;">
              <input type="submit" class="btn btn-success" name="add" value=" open course">
          </form>
    </td>

    </tr>

    <?php
    }
    ?>
    </table>
    <?php

   }


}

if(isset($add))
{
    $t_id =  $_SESSION['id'];
    if(add_course($t_id,$subject_id,$conn))
    {
  ?>
              <script>
              swal({icon: "success",});
              </script>
        <?php
    }else {
      ?>
      <script>
      swal({icon: "error",});
      </script>
  <?php

  }

}


if(isset($close_course))
{

  if(select_courses_status($_SESSION['id'],$result,$conn)){
    ?>
    <table class="table table-striped">
    <thead>
    <tr>
      <th scope="col">subject name</th>
    
    </tr>
  </thead>
    <?php
  foreach ($result as $key => $value) {
    ?>
  <tr>


  <td><?= $result[$key]['name']?></td>

  <td>
        <form action="" method="post">
            <input type="text" name="subject_id" value="<?= $result[$key]['id']?>" style="display: none;">
            <input type="submit" class="btn btn-danger" name="close" value="close course">
        </form>
  </td>
  <td>
        <form action="Results.php" method="post">
            <input type="text" name="subject_id" value="<?= $result[$key]['id']?>" style="display: none;">
            <input type="submit" class="btn btn-danger" name="get_st" value="Results">
        </form>
  </td>

  </tr>

  <?php
  }
  ?>
  </table>
  <?php

  }
}


if(isset($close))
{
  if(close_course($subject_id,$result,$conn))
  {
    ?>
                <script>
                swal({icon: "success",});
                </script>
          <?php
      }else {
        ?>
        <script>
        swal({icon: "error",});
        </script>
    <?php

    }
}

 
