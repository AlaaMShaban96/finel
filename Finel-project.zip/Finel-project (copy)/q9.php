<?php
session_start();
include "connection.php";
include "functions.php";
extract($_POST);

if (isset($results)) {
  # code...

if(show_results($_SESSION['s_id'],$result,$conn))
{
?>
<table border="1">
  <tr><td>course id</td><td>mid</td><td>final</td></tr>
  <?php
  foreach ($result as $key => $value) {
     ?>

    <tr><td><?= $result[$key]['c_id'] ?> </td>
  <td> <?= $result[$key]['mid'] ?></td>
  <td><?= $result[$key]['final'] ?></td></tr>
  <?php

}
}
}
