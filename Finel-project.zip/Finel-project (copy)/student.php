<?php
session_start();
include 'functions.php';
include "connection.php";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="bootstrap/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title> <?= $_SESSION['name'] ?></title>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-6">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-lg-8 col-md-6">
                            <h3 class="mb-0 text-truncated"><?= $_SESSION['name'] ?></h3>

                            <p class="lead"><?= ($_SESSION['priv']=='s')? "student":"tetshar"; ?></p>
                            
                            <p> <span class="badge badge-info tags"><?= $_SESSION['phone'] ?></span>
                                <span class="badge badge-info tags"><?= $_SESSION['email'] ?></span>
                                <span class="badge badge-info tags"><?= $_SESSION['name'] ?></span>
                            </p>
                        </div>
                        <div class="col-12 col-lg-4 col-md-6 text-center">
                            <img src="<?= $_SESSION['img'] ?>" alt="" class="mx-auto rounded-circle img-fluid">
                            <br>
                         
                        </div>
                        <div class="col-12 col-lg-4">
                            <h3 class="mb-0"><?= number_of_your_courses($conn,$_SESSION['s_id']) ?></h3>
                           
                            <form action="" method="post" >
                                 <input type="submit" class="btn btn-primary" value="Your Courses"name="my_courses"><span class="fa fa-user"></span>  
                            </form>                        </div>
                        <div class="col-12 col-lg-4">
                            <h3 class="mb-0"><?= number_of_courses($conn) ?></h3>
                            
                            <form action="" method="post" >
                                 <input type="submit" class="btn btn-dark" value="All Courses" name="all_courses"><span class="fa fa-user"></span> 
                            </form>
                        </div>
                        <div class="col-12 col-lg-4">
                            
                           
                        <form action="index.php" method="get" >
                                 <input type="submit" class="btn btn-warning" value="Log out " name="logout">
                            </form>                        
                        <form action="q9.php" method="post" >
                                 <input type="submit" class="btn btn-warning" value="Show my results " name="results">
                            </form>                        
                        </div>
                       
                        <!--/col-->
                    </div>
                    <!--/row-->
                </div>
                <!--/card-block-->
            </div>
        </div>
    </div>
</div>
    
</body>
</html>
<?php
extract($_POST);
if (isset($all_courses)) {
    
     
    
    ?>
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"> Number of cord</th>
      <th scope="col">Name</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
    <?php
      $courses =all_courses($conn,$_SESSION['s_id']);
      
    foreach ($courses as $val =>$e) {
        ?>
    <tr>
      <td><?= $e['id']?></th>

      <td><?= $e['name']?></td>

      <td>
            <form action="student.php" method="post">
                <input type="text" name="c_id" value="<?= $e['id']?>" style="display: none;">
                <input type="submit" class="btn btn-success" name="add_c" value=" Add">
            </form>
      </td>

    </tr>

        <?php
    }
    ?>
  </table>
    <?php
   
    
    }


if (isset($my_courses)) {
   
    
    ?>
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"> Number of cord</th>
      <th scope="col">Name</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
    <?php
      $courses =my_courses($conn,$_SESSION['s_id']);
      
    foreach ($courses as $val =>$e) {
        ?>
    <tr>
      <td><?= $e['id']?></th>

      <td><?= $e['name']?></td>

      <td>
            <form action="student.php" method="post">
                <input type="text" name="c_id" value="<?= $e['id']?>" style="display: none;">
                <input type="submit" class="btn btn-danger" name="drop_c" value=" Drop">
            </form>
      </td>

    </tr>

        <?php
    }
    ?>
  </table>
    <?php
   
    
 }
if (isset($drop_c)) {

   if( drop_courses($conn,$_SESSION['s_id'],$c_id)){
       ?>
            <script>
            swal({icon: "success",});
            </script>
       <?php

   }else {
    ?>
            <script>
            swal({icon: "error",});
            </script>
    <?php

   }
    
 }
if (isset($add_c)) {
    if( add_courses($conn,$_SESSION['s_id'],$c_id)){
        ?>
             <script>
             swal({icon: "success",});
             
             </script>
        <?
      
    }else {
     ?>
             <script>
             swal({icon: "error",});
            
             </script>
     <?php
      
    }
 
   
 }
