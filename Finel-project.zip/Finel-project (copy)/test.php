<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="" method="post">


    <button type="submit" name="add">add</button>

</form>
<form  action="" method="post">
  <button type="submit" name="subject">update</button>
  <input type="number" name="id" value="">

</form>
  </body>
</html>
