<!DOCTYPE html>
<?php include "connection.php";
include "functions.php";
session_start();
 $GLOBALS['x']  = array();
?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php 

extract($_POST);
if(isset($get_st)){
$_SESSION["subject_id_Global"]=$subject_id;

  if (get_Sts_in_cr($subject_id,$result,$conn)){


         if(get_gred($_SESSION['s_id'],$subject_id,$result_for_gred,$conn)){



          echo '<form id="insert_st" method="post"> 
           <table border="1">
                  <tr>
                    <th>Student ID</th>
                    <th>Mid</th>
                    <th>Final</th>
                  </tr>';
                  foreach ($result as $key => $value) {

                  echo '
                  <tr>
                  
                        <td>'.$result[$key]['s_id'].'</td>
                        <input type="text" name="stud_id" value="'.$result[$key]['s_id'].'" style="display: none;">
                        <td><input type="text" name="mid'.$key.'" value="'.$result_for_gred[$key]['mid'].'"></td>
                        <td><input type="text" name="final'.$key.'" value="'.$result_for_gred[$key]['final'].'"></td>
                        <td><button type="submit" name="update_grade">Edit</button></td>
                  
                  
                  
                  </tr>';
          }

          echo '</table>
         
          </form>';



         }else {

              echo '<form id="insert_st" method="post"> 
                        <table border="1">
                            <tr>
                              <th>Student ID</th>
                              <th>Mid</th>
                              <th>Final</th>
                            </tr>';

                            foreach ($result as $key => $value) {
                                  echo '
                                <tr>  
                                  <td>'.$result[$key]['s_id'].'</td>
                                  <input type="text" name="stud_id" value="'.$result[$key]['s_id'].'" style="display: none;">
                                  <td><input type="text" name="mid" value="0"></td>
                                  <td><input type="text" name="final" value="0"></td>
                                  <td><button type="submit" name="insert_deg">Save</button></td>
                              <tr>
                                  ';
                            }

                            echo '</table>
                      
                   </form>';
           
            }


  }else {
               
    echo "nnnnnnnnnnnn";
    
  }
  // get_gred($_SESSION['s_id'],$subject_id, $result3,$conn);// get all id for stud*

  // get_Sts_in_cr($_SESSION['s_id'],$result,$conn);
  
//   if (get_Sts_in_cr($_SESSION['s_id'],$result,$conn)) {

//         // $_SESSION['t_ide'] = $subj;
//         // get_Sts_in_cr($_SESSION['s_id'],$result,$conn);




//         if ($result == 0) {

//           echo "";

//         } else {
//             echo '<form id="insert_st" method="post">  <table border="1">
//                 <tr>
//                   <th>Student ID</th>
//                   <th>Mid</th>
//                   <th>Final</th>
//                 </tr>';

//                 foreach ($result as $key => $value) {
//                       echo '<td>'.$result[$key]['s_id'].'</td>
//                       <td><input type="text" name="mid'.$key.'" value="0"></td>
//                       <td><input type="text" name="final'.$key.'" value="0"></td></tr>';
//                 }

//                 echo '</table>
//                 <button type="submit" name="insert_deg">Save</button>
//                 </form>';
//       }

// }else {
//         $_SESSION['t_ide'] = $subj;
//         echo $_SESSION['t_ide'];
//         get_Sts_in_cr($subj,$result,$conn);

//         if ($result == 0) {

//               echo '<script>alert("There is no Students Regiseted")</script>';

//         }else {
//               echo '<form id="insert_st" method="post">  <table border="1">
//                   <tr>
//                     <th>Student ID</th>
//                     <th>Mid</th>
//                     <th>Final</th>
//                   </tr>';
//                   foreach ($result as $key => $value) {

//                           echo '<td>'.$result[$key]['s_id'].'</td>
//                           <td><input type="text" name="mid'.$key.'" value="'.$result3[$key]['mid'].'"></td>
//                           <td><input type="text" name="final'.$key.'" value="'.$result3[$key]['final'].'"></td></tr>';
//                   }

//                   echo '</table>
//                   <button type="submit" name="update_grade">Edit</button>
//                   </form>';
//           }
//     }

  }




if (isset($insert_deg)) {
   
   if (insert_deg( $stud_id,$_SESSION["subject_id_Global"],$_SESSION['s_id'],$mid,$final,$result2,$conn)){
   
  echo"";
   }else {
    echo $result2;

   }
      
     
}






if (isset($update_grade)) {


  //get_Sts_in_cr($_SESSION['t_ide'],$result,$conn);

  if (insert_deg( $stud_id,$_SESSION["subject_id_Global"],$_SESSION['s_id'],$mid,$final,$result2,$conn)){
   
  echo"";
   }else {
    echo $result2;

   }
      
}

    ?>
  </body>
</html>
